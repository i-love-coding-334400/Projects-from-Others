### ABGZ_idle0_0_19_6
- 20 * 0.8 training samples
- tested it a couple of times and it works quite well

### ABGZ_idle0_1_19_6
- 20 * 0.8 training samples
- NO. B is mostly recognized for Z

### AGZ_idle0_1_19_6
- 20 * 0.8 training samples
- Works, but only has 3 gestures