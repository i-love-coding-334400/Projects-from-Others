JSProbability
=============

A JavaScript statistical probability library.
