THIS IS AN OPEN SOURCE HMM TOOLBOX. IT IS FREE FOR INDIVIDUALS & RESEARCH. 
IF YOU ARE USING IT FOR COMMERCIAL USE, PLEASE CONTACT THE AUTHOR FIRST. 
AUTHOR: QIUQIANG KONG
CONTACT: qiuqiangkong@gmail.com
CREATE: 25-11-2015 v0.1
Modified: 28-06-2016 v0.2
==========================================

Usage:
1. run test_gmm.m

==========================================
