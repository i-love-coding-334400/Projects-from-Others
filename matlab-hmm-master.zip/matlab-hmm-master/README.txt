THIS IS AN OPEN SOURCE HMM TOOLBOX. IT IS FREE FOR INDIVIDUALS & RESEARCH. 
IF YOU ARE USING IT FOR COMMERCIAL USE, PLEASE CONTACT THE AUTHOR. 
AUTHOR: QIUQIANG KONG
CONTACT: qiuqiangkong@gmail.com
CREATE: 25-11-2015
==========================================

Usage:
2. run test_hmm.m

==========================================

1. Providing Multinominal-HMM, Gaussian-HMM, GMM-HMM. 
2. Underflow problem has been solved by applying log and normalization. 

==========================================


